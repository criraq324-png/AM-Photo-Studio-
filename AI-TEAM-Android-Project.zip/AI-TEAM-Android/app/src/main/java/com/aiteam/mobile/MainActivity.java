package com.aiteam.mobile;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 17, 29);
    private static final int CARD = Color.rgb(24, 32, 49);
    private static final int ACCENT = Color.rgb(124, 92, 255);
    private static final String PREF = "aiteam_local";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private LinearLayout root, messages;
    private EditText input;
    private TextView status;
    private ScrollView scroll;
    private SharedPreferences prefs;
    private String openAiKey = "", anthropicKey = "";
    private String openAiModel = "gpt-4.1-mini";
    private String claudeModel = "claude-sonnet-4-5";
    private boolean busy = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREF, MODE_PRIVATE);
        openAiKey = readSecret("openai");
        anthropicKey = readSecret("anthropic");
        openAiModel = prefs.getString("openai_model", "gpt-4.1-mini");
        claudeModel = prefs.getString("claude_model", "claude-sonnet-4-5");
        buildUi();
        loadHistory();
        if (openAiKey.isEmpty() || anthropicKey.isEmpty()) {
            addBubble("مرحباً! أنا AI TEAM. افتح الإعدادات وأضف مفتاح OpenAI ومفتاح Anthropic حتى يعمل الفريق.", false);
        }
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(10));
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = new TextView(this);
        brand.setText("AI TEAM");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(25);
        brand.setTypeface(null, Typeface.BOLD);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = button("الإعدادات");
        settings.setOnClickListener(v -> showSettings());
        top.addView(settings);
        root.addView(top);

        TextView subtitle = new TextView(this);
        subtitle.setText("فريقك الذكي • ChatGPT يخطط وClaude ينفّذ");
        subtitle.setTextColor(Color.rgb(169, 180, 205));
        subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(5), 0, dp(12));
        root.addView(subtitle);

        status = new TextView(this);
        status.setText("جاهز لاستقبال المهمة");
        status.setTextColor(Color.rgb(151, 221, 183));
        status.setTextSize(12);
        status.setPadding(dp(12), dp(8), dp(12), dp(8));
        status.setBackground(round(CARD, 14));
        root.addView(status);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, dp(12), 0, dp(12));
        scroll.addView(messages);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sp.topMargin = dp(8);
        root.addView(scroll, sp);

        input = new EditText(this);
        input.setHint("اكتب المهمة التي تريد من الفريق تنفيذها...");
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.rgb(145, 155, 176));
        input.setTextSize(15);
        input.setGravity(Gravity.TOP | Gravity.RIGHT);
        input.setMinLines(2);
        input.setMaxLines(5);
        input.setPadding(dp(13), dp(12), dp(13), dp(12));
        input.setBackground(round(CARD, 16));

        root.addView(input, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        Button clear = button("مسح المحادثة");
        clear.setOnClickListener(v -> confirmClear());
        Button send = button("تشغيل الفريق");
        send.setBackground(round(ACCENT, 15));
        send.setOnClickListener(v -> runTeam());
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, dp(48), 1);
        left.rightMargin = dp(8);
        actions.addView(clear, left);
        actions.addView(send, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = dp(8);
        root.addView(actions, ap);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(round(CARD, 14));
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density); }

    private void addBubble(String text, boolean user) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(14);
        tv.setTextIsSelectable(true);
        tv.setGravity(Gravity.RIGHT);
        tv.setPadding(dp(14), dp(12), dp(14), dp(12));
        tv.setBackground(round(user ? Color.rgb(65, 53, 125) : CARD, 16));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(9);
        p.leftMargin = user ? dp(28) : 0;
        p.rightMargin = user ? 0 : dp(28);
        messages.addView(tv, p);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void loadHistory() {
        String history = prefs.getString("history", "");
        if (history.isEmpty()) return;
        try {
            JSONArray a = new JSONArray(history);
            for (int i=0; i<a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                addBubble(o.optString("text"), o.optBoolean("user"));
            }
        } catch (Exception ignored) {}
    }

    private void saveHistory(String text, boolean user) {
        try {
            JSONArray a = new JSONArray(prefs.getString("history", "[]"));
            a.put(new JSONObject().put("text", text).put("user", user));
            while (a.length() > 80) a.remove(0);
            prefs.edit().putString("history", a.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void confirmClear() {
        new AlertDialog.Builder(this).setTitle("مسح المحادثة")
            .setMessage("هل تريد حذف سجل المحادثة المحفوظ على الهاتف؟")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("مسح", (d,w) -> {
                messages.removeAllViews();
                prefs.edit().remove("history").apply();
                addBubble("تم مسح المحادثة. مشاريعك القادمة ستُحفظ محلياً على هذا الهاتف.", false);
            }).show();
    }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(18), dp(8), dp(18), dp(4));
        box.setOrientation(LinearLayout.VERTICAL);
        EditText oa = field("OpenAI API Key", openAiKey, true);
        EditText an = field("Anthropic API Key", anthropicKey, true);
        EditText om = field("OpenAI model", openAiModel, false);
        EditText cm = field("Claude model", claudeModel, false);
        box.addView(oa); box.addView(an); box.addView(om); box.addView(cm);
        new AlertDialog.Builder(this).setTitle("إعدادات الفريق")
            .setView(box)
            .setMessage("المفاتيح تُشفّر محلياً باستخدام Android Keystore. لا تشاركها مع أحد.")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ", (d,w) -> {
                openAiKey = oa.getText().toString().trim();
                anthropicKey = an.getText().toString().trim();
                openAiModel = om.getText().toString().trim();
                claudeModel = cm.getText().toString().trim();
                if (openAiModel.isEmpty()) openAiModel = "gpt-4.1-mini";
                if (claudeModel.isEmpty()) claudeModel = "claude-sonnet-4-5";
                writeSecret("openai", openAiKey);
                writeSecret("anthropic", anthropicKey);
                prefs.edit().putString("openai_model", openAiModel)
                    .putString("claude_model", claudeModel).apply();
                addBubble("تم حفظ إعدادات الفريق على الهاتف.", false);
            }).show();
    }

    private EditText field(String hint, String value, boolean secret) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(value);
        e.setHint(hint);
        e.setTextSize(14);
        if (secret) e.setInputType(129);
        return e;
    }

    private void runTeam() {
        String task = input.getText().toString().trim();
        if (task.isEmpty() || busy) return;
        if (openAiKey.isEmpty() || anthropicKey.isEmpty()) {
            showSettings();
            status.setText("أضف مفتاحَي API أولاً");
            return;
        }
        input.setText("");
        hideKeyboard();
        addBubble("المهمة: " + task, true);
        saveHistory("المهمة: " + task, true);
        busy = true;
        status.setText("ChatGPT يضع الخطة...");
        worker.execute(() -> {
            try {
                String plan = callOpenAI(task);
                runOnUiThread(() -> {
                    addBubble("خطة ChatGPT:\n" + plan, false);
                    saveHistory("خطة ChatGPT:\n" + plan, false);
                    status.setText("Claude يعمل على التنفيذ...");
                });
                String result = callClaude(task, plan);
                runOnUiThread(() -> {
                    addBubble("نتيجة Claude:\n" + result, false);
                    saveHistory("نتيجة Claude:\n" + result, false);
                    status.setText("اكتملت المهمة • تم حفظ المحادثة محلياً");
                    busy = false;
                });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    addBubble("تعذّر إكمال المهمة:\n" + ex.getMessage(), false);
                    saveHistory("تعذّر إكمال المهمة:\n" + ex.getMessage(), false);
                    status.setText("حدث خطأ — تحقق من المفاتيح والإنترنت");
                    busy = false;
                });
            }
        });
    }

    private String callOpenAI(String task) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", openAiModel);
        body.put("messages", new JSONArray()
            .put(new JSONObject().put("role","system").put("content",
                "أنت مدير مشروع في فريق AI TEAM. حلل طلب المستخدم، واكتب خطة تنفيذ واضحة ومقسمة إلى خطوات، مع المتطلبات والمخاطر والتحقق. أجب بالعربية."))
            .put(new JSONObject().put("role","user").put("content", task)));
        body.put("temperature", 0.3);
        JSONObject response = postJson("https://api.openai.com/v1/chat/completions",
            body, "Authorization", "Bearer " + openAiKey);
        return response.getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content");
    }

    private String callClaude(String task, String plan) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", claudeModel);
        body.put("max_tokens", 3500);
        body.put("system", "أنت مهندس البرمجة في AI TEAM. نفذ الخطة عملياً، راجعها، واذكر الملفات أو الأكواد أو الخطوات المطلوبة بوضوح. لا تدّع تنفيذ شيء خارج المحادثة. أجب بالعربية.");
        body.put("messages", new JSONArray().put(new JSONObject().put("role","user")
            .put("content", "طلب المستخدم:\n" + task + "\n\nخطة ChatGPT:\n" + plan
                + "\n\nنفّذ دورك كمهندس، وقدم الناتج مع مراجعة الأخطاء. إذا احتجت ملفات غير متاحة فاطلبها بوضوح.")));
        JSONObject response = postJson("https://api.anthropic.com/v1/messages",
            body, "x-api-key", anthropicKey);
        JSONArray content = response.getJSONArray("content");
        StringBuilder out = new StringBuilder();
        for (int i=0; i<content.length(); i++) {
            JSONObject block = content.getJSONObject(i);
            if ("text".equals(block.optString("type"))) {
                if (out.length() > 0) out.append("\n");
                out.append(block.optString("text"));
            }
        }
        return out.toString();
    }

    private JSONObject postJson(String endpoint, JSONObject body, String authName, String authValue) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(endpoint).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(25000);
        c.setReadTimeout(90000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty(authName, authValue);
        if (endpoint.contains("anthropic.com")) {
            c.setRequestProperty("anthropic-version", "2023-06-01");
        }
        byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
        c.getOutputStream().write(data);
        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n;
        while ((n = stream.read(buf)) > 0) out.write(buf, 0, n);
        c.disconnect();
        String raw = new String(out.toByteArray(), StandardCharsets.UTF_8);
        JSONObject obj = new JSONObject(raw);
        if (code < 200 || code >= 300) {
            String msg = obj.optJSONObject("error") != null
                ? obj.getJSONObject("error").optString("message", raw) : raw;
            throw new Exception("HTTP " + code + ": " + msg);
        }
        return obj;
    }

    private SecretKey getSecretKey() throws Exception {
        java.security.KeyStore ks = java.security.KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias("aiteam_key")) return ((java.security.KeyStore.SecretKeyEntry)
            ks.getEntry("aiteam_key", null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder("aiteam_key",
            KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build());
        return kg.generateKey();
    }

    private void writeSecret(String name, String value) {
        try {
            if (value.isEmpty()) { prefs.edit().remove(name + "_secret").apply(); return; }
            SecretKey key = getSecretKey();
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
            byte[] iv = cipher.getIV();
            byte[] all = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, all, 0, iv.length);
            System.arraycopy(encrypted, 0, all, iv.length, encrypted.length);
            prefs.edit().putString(name + "_secret", android.util.Base64.encodeToString(all, 2)).apply();
        } catch (Exception e) { Toast.makeText(this, "تعذّر تشفير المفتاح", Toast.LENGTH_LONG).show(); }
    }

    private String readSecret(String name) {
        try {
            String value = prefs == null ? "" : prefs.getString(name + "_secret", "");
            if (value.isEmpty()) return "";
            byte[] all = android.util.Base64.decode(value, 2);
            byte[] iv = new byte[12];
            System.arraycopy(all, 0, iv, 0, 12);
            byte[] enc = new byte[all.length - 12];
            System.arraycopy(all, 12, enc, 0, enc.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(enc), StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }

    private void hideKeyboard() {
        try {
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(input.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        worker.shutdownNow();
    }
}
