# AI TEAM — Android app source

تطبيق Android مستقل (Java) بواجهة عربية. يقوم ChatGPT عبر OpenAI API بوضع خطة، ثم يرسل الخطة إلى Claude عبر Anthropic API ليقدم مراجعة/تنفيذاً نصياً. يحفظ سجل المحادثة محلياً، ويشفّر مفاتيح API باستخدام Android Keystore.

## المتطلبات
- Android Studio حديث
- JDK 17
- Android SDK Platform 35
- اتصال إنترنت عند استدعاء النماذج
- مفتاح OpenAI API ومفتاح Anthropic API منفصلان (اشتراكات ChatGPT/Claude لا تتضمن تلقائياً رصيد API)

## فتح وبناء APK
1. فك ضغط الملف.
2. افتح مجلد `AI-TEAM-Android` في Android Studio.
3. انتظر Gradle Sync وثبّت Android SDK Platform 35 إذا طُلب.
4. اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5. ستجد APK عادةً في `app/build/outputs/apk/debug/app-debug.apk`.

## الإعداد داخل التطبيق
من زر «الإعدادات» أدخل:
- OpenAI API Key
- Anthropic API Key
- OpenAI model (الافتراضي `gpt-4.1-mini`)
- Claude model (الافتراضي `claude-sonnet-4-5`)

تحقق من أن النموذجين متاحان لحسابَي API. الاستخدام قد يترتب عليه رسوم منفصلة حسب استهلاك API.

## حدود النسخة الأولى
- التطبيق ينسّق بين النموذجين بالتتابع: ChatGPT يخطط ثم Claude يراجع/ينفذ نصياً.
- لا يشغّل كوداً على الهاتف، ولا يعدّل ملفات مشروعك تلقائياً في هذه النسخة.
- السجل محفوظ محلياً؛ لا توجد مزامنة سحابية أو حسابات متعددة.
- لا تضع مفاتيح API في مستودع عام أو تشاركها. المفاتيح تحفظ مشفرة محلياً باستخدام Android Keystore، لكن استخدام وسيط خادم آمن أفضل لتطبيق إنتاجي متعدد المستخدمين.
- هذه حزمة مصدر؛ لم يتم التحقق من بنائها في هذه البيئة لعدم توفر Android SDK/Gradle هنا.
